import { Component, Input } from '@angular/core';
import {
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogTitle,
} from '@angular/material/dialog';
import { ClientFormBaseComponent } from '../client-form-base/client-form-base.component';
import { ClientForm } from '../../interfaces';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-add-client-dialog',
  standalone: true,
  imports: [
    ClientFormBaseComponent,
    MatDialogActions,
    MatDialogClose,
    MatDialogContent,
    MatDialogTitle,
  ],
  templateUrl: './add-client-dialog.component.html',
  styleUrl: './add-client-dialog.component.scss',
})
export class AddClientDialogComponent {
  @Input() title = '';

  submit(ev: FormGroup<ClientForm>) {

  }
}
