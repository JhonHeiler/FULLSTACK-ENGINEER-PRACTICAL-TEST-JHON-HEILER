import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';

// components
import { SearchBarComponent } from '../../components/search-bar/search-bar.component';
import { SidenavComponent } from '../../components/sidenav/sidenav.component';
import { AddClientDialogComponent } from '../../components/add-client-dialog/add-client-dialog.component';
import { ClientService } from '../../services/client.service';
import { ClientDTO } from '../../dto/client.dto';

@Component({
  selector: 'app-clients',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    SearchBarComponent,
    SidenavComponent,
  ],
  templateUrl: './clients.component.html',
  styleUrl: './clients.component.scss',
})
export class ClientsComponent implements OnInit {
  dataSource: ClientDTO[] = [];
  tableSchema = [
    { key: 'sharedKey', label: 'Shared Key' },
    { key: 'name', label: 'Business ID' }, 
    { key: 'email', label: 'E-mail' },
    { key: 'phone', label: 'Phone' },
    { key: 'startDate', label: 'Data Added' },
  ];
  displayedColumns = [...this.tableSchema.map(e => e.key), 'actions'];

  constructor(private matDialog: MatDialog, private clientService: ClientService) { }

  ngOnInit() {
    this.loadClients();
  }

  openDialog() {
    this.matDialog
      .open(AddClientDialogComponent)
      .beforeClosed()
      .subscribe((res) => {
        this.loadClients();
      });
  }

  loadClients() {
    this.clientService.getClientsPage(0, 10).subscribe(clients => {
      this.dataSource = clients;
    });
  }
}
