export interface ClientDTO {
  sharedKey: string;
  name: string;
  email: string;
  phone: string;
  startDate: string;
  endDate: string;
}
